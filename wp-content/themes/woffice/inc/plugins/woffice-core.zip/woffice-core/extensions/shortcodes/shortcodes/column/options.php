<?php if (!defined('FW')) die('Forbidden');

$options = array(
	'extraclasses' => array(
		'label'   => __('Extra Class to the column', 'woffice'),
		'desc'    => __('Such as: center to align in the middle the content inside.', 'woffice'),
		'type'    => 'text'
	),
);